//
// Created by user on 14/11/16.
//

#include "Plot.h"

Plot::Plot()
{
    hauteur = 10;
}

int Plot::getHauteur() {return hauteur;}