//
// Created by user on 14/11/16.
//

#include "Objet.h"

Objet::Objet() {poids = 5;}
int Objet::getPoids() {return poids;}